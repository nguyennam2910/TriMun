function c = cols( w)
%	Returns the number of columns of matrix w.

[r, c] = size( w);
