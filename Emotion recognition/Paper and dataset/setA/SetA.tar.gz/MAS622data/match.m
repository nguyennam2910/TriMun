if 0
cd /mas/disks/vismod/grad/fenn/EXPERIMENTS/SENTICS/DATA/MAT
load BVPr.mat
cd /mas/vision/projects/AC/Notes-physiology/Elias/data
load day1.mat
end

p = 9;

for j=1:32
if( sum( size( find( day1(p,j)==BVPr_100)))
  j,i
end
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_58))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_71))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_85))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_94))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_105))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_60))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_72))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_86))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_99))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_107))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_62))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_75))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_87))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_37))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_64))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_76))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_88))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_43))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_65))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_79))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_89))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_45))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_67))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_81))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_90))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_49))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_68))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_82))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_91))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_51))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_69))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_84))
end
i = i+1;
for j=1:32
size( find( day1(p,j)==BVPr_93))
end

P = {BVPr_100    BVPr_58     BVPr_71     BVPr_85     BVPr_94
BVPr_105    BVPr_60     BVPr_72     BVPr_86     BVPr_99
BVPr_107    BVPr_62     BVPr_75     BVPr_87
BVPr_37     BVPr_64     BVPr_76     BVPr_88
BVPr_43     BVPr_65     BVPr_79     BVPr_89
BVPr_45     BVPr_67     BVPr_81     BVPr_90
BVPr_49     BVPr_68     BVPr_82     BVPr_91
BVPr_51     BVPr_69     BVPr_84     BVPr_93};
