loadall

cd ../fulldata/

index
load EMGj
load BVPw
load GSR
load RESPw

