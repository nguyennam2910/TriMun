if 0
cd /mas/disks/vismod/grad/fenn/EXPERIMENTS/SENTICS/DATA/MAT
load BVPr.mat
cd /mas/vision/projects/AC/Notes-physiology/Elias/data
load day1.mat
end

p = 9;

for i = 1:34
  for j=1:32
    if( sum( size( find( day1(p,j) == P{i})))
      j,i
    end
  end
end

%P = {BVPr_100    BVPr_58     BVPr_71     BVPr_85     BVPr_94 BVPr_105 BVPr_60     BVPr_72     BVPr_86     BVPr_99 BVPr_107    BVPr_62     BVPr_75 BVPr_87 BVPr_37     BVPr_64     BVPr_76     BVPr_88 BVPr_43     BVPr_65 BVPr_79     BVPr_89 BVPr_45     BVPr_67     BVPr_81     BVPr_90 BVPr_49 BVPr_68     BVPr_82     BVPr_91 BVPr_51     BVPr_69     BVPr_84     BVPr_93};

