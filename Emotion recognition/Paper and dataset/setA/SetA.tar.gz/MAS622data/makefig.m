fixes9                
figure(1)             
print -dps figure19.ps
figure(2)             
print -dps figure20.ps
fixes10               
figure(1)             
print -dps figure21.ps
figure(2)             
print -dps figure22.ps
fixes11
figure(1)             
print -dps figure23.ps
figure(2)             
print -dps figure24.ps
fixes12
figure(1)             
print -dps figure25.ps
figure(2)             
print -dps figure26.ps
fixes13               
figure(1)             
print -dps figure27.ps
figure(2)             
print -dps figure28.ps
fixes14
print -dps figure29.ps
figure(1)             
print -dps figure29.ps
figure(2)             
print -dps figure30.ps

