function r = rows( w)
%	Returns the number of rows of matrix w.

[r, c] = size( w);
